'''

##########################################
Data set containing common dns subdomains. 
##########################################

'''
#Customize this#
subdomains = ['ns0','ns1','ns2']

normal_subdomains = ['test', 'online', 'remote', 'read', 'dns', 'smtp', 'pants', 'socks', 'front', 'back', 'left', 'right', 'up', 'down', 'sub', 'relate', 'answer', 'bag', 'box', 'peg', 'chair', 'phone', 'speaker', 'remote', 'light', 'lantern', 'roller', 'vase', 'small', 'tiny', 'sauce']