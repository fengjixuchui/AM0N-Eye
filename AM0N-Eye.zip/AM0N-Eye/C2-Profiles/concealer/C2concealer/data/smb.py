'''

##################################################################################
Data set for smb block pipenames. Note that the format is 
word_##, where CS will auto include a two digit number in the "##" field.
##################################################################################

'''
#Customize this#
pipenames = ['npfs_##', 'fullduplex_##', 'halfduplex_##', 'dce_##', 'rpc_##']