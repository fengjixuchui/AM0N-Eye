
To use:

Run 'unhook' from Beacon

To build:

x86: Open Visual Studio x86 Native Tools Command Prompt and type 'make'
x64: Open Visual Studio x64 Croos Tools Command Prompt and type 'make'


